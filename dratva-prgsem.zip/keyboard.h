/*
  filename: keyboard.h
  author: dratvsim
*/

#ifndef __KEYBOARD_H__
#define __KEYBOARD_H__

void* keyboard_thread(void* d);

#endif

/*end of keyboard.h*/