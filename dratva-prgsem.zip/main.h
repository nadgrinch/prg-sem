/*
  filename: main.h
  author: dratvsim
*/

#ifndef __MAIN_H__
#define __MAIN_H__

void* main_thread(void* d);

#endif

/*end of main.h*/